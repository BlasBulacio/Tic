package com.example.a42512901.tpadivinarpaises;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class objetivos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objetivos);

    }
}

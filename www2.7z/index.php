<html>
	<body>	
		<form name="formulario" action="a.php" method="POST">
			Tu nombre <input type="text" name="nombre"><br>
			Ingrese email <input type="text" name="email"><br>
			Ingrese contraseña <input type="password" name="contraseña"><br>
			Confirmar contraseña <input type="password" name="contraseña1"><br>
			<input type="radio" name="genero" value="hombre"> hombre<br>
			<input type="radio" name="genero" value="mujer"> mujer<br>
			Elija un color
			<select name="color">
			<option value="rojo">rojo</option>
			<option value="azul">azul</option>
			<option value="violeta">violeta</option>
			</select> <br>
			Dia
			<select name="dias">
			<?php
			for($i=1; $i<=31; $i++){
			 echo "<option value=$i>$i</option>";
			}			
			?>
			</select> <br>
			Mes
			<select name="meses">
			<?php
			for($i=1; $i<=12; $i++){
			 echo "<option value=$i>$i</option>";
			}			
			?>
			</select> <br>
			Año <select name="años">
			<?php
			for($i=1900; $i<=2017; $i++){
			 echo "<option value=$i>$i</option>";
			}			
			?>
			</select> <br>
			
			Ultima pelicula que viste? <input type="text" name="pelicula"><br>
			<input type="submit" name="enviar" value="Enviar">
		</form>
	</body>
</html>


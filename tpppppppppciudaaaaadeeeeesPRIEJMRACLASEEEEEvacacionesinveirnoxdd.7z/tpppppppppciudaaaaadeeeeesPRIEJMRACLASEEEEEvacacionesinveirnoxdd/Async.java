package com.example.a42512901.myapplication;

import android.os.AsyncTask;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import static java.lang.System.in;

/**
 * Created by 42512901 on 11/7/2017.
 */

public class Async extends AsyncTask<String, Integer, Ciudad>{
    @Override
    int longitudStream;
    int actualStream;
    protected Ciudad doInBackground(String... params) {
        String wata = "";
        /*Traer json*/
        try {
            URL url = new URL("http://www.android.com/");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            try {
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                char curr = (char) in.read();
                longitudStream = in.available();
                actualStream = 0;
                while(curr != 0)
                {
                    wata += curr;
                    curr = (char) in.read();
                    actualStream++;
                }
            } finally {
                urlConnection.disconnect();
            }
        }catch (MalformedURLException ex){
            return null;
        }
        catch(IOException ex)
        {
            return null;
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);

    }
}

/*traer json del sitio web*/
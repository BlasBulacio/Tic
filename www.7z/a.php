<html>
	<body>	
		<?PHP
			if (isset($_POST["enviar"]))
			{
				if($_POST["contraseña"]!="" && $_POST["contraseña"]==$_POST["contraseña1"]){
				if ($_POST["nombre"]!="")	
				{
					echo "Hola ".$_POST["nombre"];
				}
				else
				{
					echo "infradotado complete el nombre";
				}
				
				if($_POST["genero"]!=""){
							echo ". Sos ".$_POST["genero"];
				}else
				{
					echo ". No elegiste genero";
				}
				if($_POST["color"]!=""){
							echo ". Elegiste el color ".$_POST["color"];
				}else
				{
					echo ". No elegiste color";
				}
				
				if ($_POST["pelicula"]!="")	
				{
					echo ". Viste ".$_POST["pelicula"];
				}
				else
				{
					echo ". No ingresaste película";
				}
				}else{
					echo "Ingrese bien la pass.";
				}
				echo ". Naciste el ".$_POST["dias"]."/".$_POST["meses"]."/".$_POST["años"];
			}
			else
			{
				echo "imbecil vaya al  formulario";
				echo "<a href=\"index		.php\">volver</a>";
			}
			?>
			
	</body>
</html>
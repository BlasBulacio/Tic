package com.example.a42512901.myapplication;

/**
 * Created by 42512901 on 11/7/2017.
 */

public class Ciudad {
    public String clase;
    public String countrycode;
    public long lat;
    public long lng;
    public String name;
    public int population;
}

package com.example.a42512901.primertpsql;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class mostrar extends AppCompatActivity {
    TextView txtMostrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);
        ObtenerReferencias();
        UsuariosSQLiteHelper usdbh = new UsuariosSQLiteHelper(this, "Users", null, 1);
        SQLiteDatabase db = usdbh.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM Users", null);
        while (c.moveToNext()) {
        txtMostrar.setText(c.getString(0));
        }
    }
    public void ObtenerReferencias(){
        txtMostrar=(TextView) findViewById(R.id.txtMostrar);
    }
}

package com.example.a42512901.myapplication;

import android.icu.text.LocaleDisplayNames;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import static java.lang.System.in;

/**
 * Created by 42512901 on 11/7/2017.
 */

public class Async extends AsyncTask<String, Integer, Ciudad[]>{
    int longitudStream;
    String stringJSON;
    int bytes=0;
    public main.AsyncResponse delegar=null;
    @Override
    protected Ciudad[] doInBackground(String... params) {
        String result = null;
        StringBuffer sb = new StringBuffer();
        InputStream is = null;

        /*Traer json*/
        Log.d("BLAS", "1");
        Ciudad[] returnArray;
        try {
            URL url = new URL("https://tp4ort.firebaseio.com/geonames.json");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            try {
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                String inputLine = "";
                while ((inputLine = br.readLine()) != null) {
                    sb.append(inputLine);
                }
                result = sb.toString();
                Log.d("BLAS", "Leyo result  :" + result );



                longitudStream = in.available();
                byte[] streamtxt = new byte[longitudStream];
                in.read(streamtxt,bytes,longitudStream);

                Log.d("BLAS", "Leyo:" + streamtxt);

                stringJSON = new String(streamtxt);
                JSONArray jArr = new JSONArray(stringJSON);
                int arrLength = jArr.length();
                returnArray = new Ciudad[arrLength];
                JSONObject currObj;
                for(int i = 0; i < arrLength; ++i)
                {
                    Log.d("BLAS", String.valueOf(i));
                    currObj = jArr.getJSONObject(i);
                    returnArray[i].clase = currObj.getString("clase");
                    returnArray[i].countrycode = currObj.getString("countrycode");
                    returnArray[i].lat=currObj.getLong("lat");
                    returnArray[i].lng=currObj.getLong("lng");
                    returnArray[i].name=currObj.getString("name");
                    returnArray[i].population=currObj.getInt("population");
                }
            } finally {
                urlConnection.disconnect();
            }
        }catch (MalformedURLException ex){
            Log.d("BLAS", ex.getMessage());
            return null;
        }
        catch(IOException ex)
        {
            Log.d("BLAS", ex.getMessage());
            return null;
        }
        catch(JSONException ex)
        {
            Log.d("BLAS", ex.getMessage());
            return null;
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }

    public Async(main.AsyncResponse delegar){
        this.delegar=delegar;
    }

    public Async(){
    }
    @Override
    protected void onPostExecute(Ciudad[] ciudads) {
        Log.d("BLAS", "2");
        //delegar.procesoTerminado(ciudads);
    }


}

/*traer json del sitio web*/
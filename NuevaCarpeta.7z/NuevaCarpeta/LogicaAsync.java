package com.example.a42512901.myapplication;

/**
 * Created by 42512901 on 22/8/2017.
 */
public class LogicaAsync {
   public static Ciudad[] arrCiudades = null;
}

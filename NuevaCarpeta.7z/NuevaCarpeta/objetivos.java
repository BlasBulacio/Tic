package com.example.a42512901.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Set;

public class objetivos extends AppCompatActivity {
    TextView txt;
    Button btnComenzar;
    TextView txtespere;
    Ciudad[] arrCiudades;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objetivos);
        ObtenerReferencias();
        SetListeners();
    }

    public void ObtenerReferencias() {
        btnComenzar = (Button) findViewById(R.id.btnComenzar);
        txtespere = (TextView) findViewById(R.id.txtespere);
    }

    public void SetListeners() {
        btnComenzar.setOnClickListener(btnComenzar_click);
    }

    private View.OnClickListener btnComenzar_click = new View.OnClickListener() {
        public void onClick(View v) {
            if (LogicaAsync.arrCiudades == null) {
                txtespere.setText("Espere, se estan cargando los datos");
            } else {
                Intent myIntent = new Intent(objetivos.this, juego.class);
                startActivity(myIntent);
            }
        };
    };
}

package com.example.a42512901.primertpsql;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UsuariosSQLiteHelper extends SQLiteOpenHelper {
    String SQLCreate="CREATE TABLE Users (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT)";
    public UsuariosSQLiteHelper(Context contexto, String nombre, SQLiteDatabase.CursorFactory factory, int version) {
      super(contexto, nombre, factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(SQLCreate);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int versionAnterior, int versionNueva){
            db.execSQL("DROP TABLE IF EXISTS Users");
            db.execSQL(SQLCreate);
    }
}

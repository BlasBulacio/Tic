package com.example.a42512901.primertpsql;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.Set;


public class main extends AppCompatActivity {
    EditText edtNombre, edtId;
    Button btnInstertar, btnEliminar, btnVisualizar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ObtenerReferencias();
        SetListeners();


    }

    private void ObtenerReferencias() {
        edtNombre = (EditText) findViewById(R.id.edtNombre);
        edtId = (EditText) findViewById(R.id.edtId);
        btnInstertar = (Button) findViewById(R.id.btnInsertar);
        btnEliminar = (Button) findViewById(R.id.btnEliminar);
        btnVisualizar = (Button) findViewById(R.id.btnVisualizar);
    }

    private void SetListeners() {
        btnInstertar.setOnClickListener(btnInsertar_click);
        btnEliminar.setOnClickListener(btnEliminar_click);
        btnVisualizar.setOnClickListener(btnVisualizar_click);
    }

    private View.OnClickListener btnInsertar_click = new View.OnClickListener() {
        public void onClick(View v) {
            String nombreUser = edtNombre.getText().toString();
            UsuariosSQLiteHelper ConseguirdbUsers = new UsuariosSQLiteHelper(main.this, "Users", null, 1);
            SQLiteDatabase dbUsers = ConseguirdbUsers.getWritableDatabase();
            String SentenciaInsert = "INSERT INTO Users(nombre) VALUES (" + "'" + nombreUser + "'" + ")";
            dbUsers.execSQL(SentenciaInsert);
            Toast.makeText(getApplicationContext(), SentenciaInsert, Toast.LENGTH_LONG).show();
            dbUsers.close();
        }
    };
    private View.OnClickListener btnEliminar_click = new View.OnClickListener() {
        public void onClick(View v) {
            String idUser = edtId.getText().toString();
            UsuariosSQLiteHelper ConseguirdbUsers = new UsuariosSQLiteHelper(main.this, "Users", null, 1);
            SQLiteDatabase dbUsers = ConseguirdbUsers.getWritableDatabase();
            dbUsers.execSQL("DELETE FROM Users WHERE" + " id=" + idUser.toString() + ")");
            dbUsers.close();
        }
    };
    private View.OnClickListener btnVisualizar_click = new View.OnClickListener() {
        public void onClick(View v) {
            Intent intent = new Intent(main.this, mostrar.class);
            startActivity(intent);
        }
    };
}
package com.example.a42512901.myapplication;

import android.os.AsyncTask;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import static java.lang.System.in;

/**
 * Created by 42512901 on 11/7/2017.
 */

public class Async extends AsyncTask<String, Integer, Ciudad>{
    int longitudStream;
    byte[] streamtxt;
    int bytes=0;
    @Override
    protected Ciudad doInBackground(String... params) {
        String wata = "";
        /*Traer json*/
        try {
            URL url = new URL("https://tp4ort.firebaseio.com/countries.json");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            try {
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                longitudStream = in.available();
                in.read(streamtxt,bytes,longitudStream);
            } finally {
                urlConnection.disconnect();
            }
        }catch (MalformedURLException ex){
            return null;
        }
        catch(IOException ex)
        {
            return null;
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }


}

/*traer json del sitio web*/
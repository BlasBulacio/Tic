package com.example.a42512901.myapplication;

/**
 * Created by 42512901 on 11/7/2017.
 */

public class Ciudad {
    String Codigo;
    String Nombre;
}

package com.example.a42512901.tpsitis;

import android.os.AsyncTask;

/**
 * Created by 42512901 on 11/7/2017.
 */

public class Async extends AsyncTask<String, Integer, Ciudad>{
    @Override
    protected Ciudad doInBackground(String... params) {
        /*Traer json*/
        return null;
    }
}

/*traer json del sitio web*/
private TraerUrl(String URL){

}
package com.example.a42512901.tpsitis;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class objetivos extends AppCompatActivity {
    TextView txt;
    Button btnComenzar;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objetivos);
        ObtenerReferencias();
    }
    public void ObtenerReferencias(){
        btnComenzar=(Button) findViewById(R.id.btnComenzar);
        progressBar=(ProgressBar) findViewById(R.id.progressBar);
    }
    public void SetListeners(){
        btnComenzar.setOnClickListener(btnComenzar_click);
    }
    private View.OnClickListener btnComenzar_click = new View.OnClickListener(){
        public void onClick(View v){

        }
    };
}

package com.example.a42512901.tpsitis;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class main extends AppCompatActivity {
    EditText edtNombre;
    Button btnListo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ObtenerReferencias();
        SetListeners();
    }
    public void ObtenerReferencias(){
        edtNombre=(EditText) findViewById(R.id.edtNombre);
        btnListo= (Button) findViewById(R.id.btnListo);
    }
    public void SetListeners(){
    btnListo.setOnClickListener(btnListo_click);
    }
    private View.OnClickListener btnListo_click = new View.OnClickListener(){
        public void onClick(View v){
            User.setearNom(edtNombre.getText().toString());
            Intent myIntent = new Intent(main.this, objetivos.class);
            startActivity(myIntent);
        }
    };
}

package com.example.a42512901.tpsitis;

import android.app.Activity;

/**
 * Created by 42512901 on 28/6/2017.
 */

public class User {
    private static String nombre;
    public static String devolverNom(){
        return nombre;
    }
    public static void setearNom(String nom){
        User.nombre = nom;
    }
}
